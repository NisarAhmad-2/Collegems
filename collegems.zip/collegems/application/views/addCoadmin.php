<?php include("inc/header.php"); ?>
<style type="text/css">
<!--
.Estilo1 {color: #0000FF}
-->
</style>

<div class ="container">
    
    <?php  if($msg = $this->session->flashdata('message'))
    
    if($msg != ''):?>
            <div class="row">
                <div class="col-md-5">
                    <div class="alert alert-dismissible alert-success"> 
                     <?php echo $msg;?>
                    </div>
                </div>
            </div>
        
      <?php endif;?>
   <?php echo form_open("admin/createCoadmin",['class' =>'form-horizontal']);?>
        <h3 class="text-center Estilo1" style="text-decoration: underline">ADD COADMIN</h3>
        <br>
            <div class="row">
                  <div class="col-md-4">
                        <div class="form-group">
                              <label class="control-label"> Username</label>
                              <?php echo form_input(['name' =>'username', 'class' => 'form-control', 'placeholder' => 'Username','value'=>set_value('username')]);?>
                              <?php echo form_error('username','<div class="text-danger">','</div>'); ?>
                        </div>
                  </div>
                  
                  <div class="col-md-4">
                              <label class="control-label"> College Name </label>
                              <select class="form-control" name="college_id">
                                    <option value=""> Select </option>
                                    <?php if(count($colleges)): ?>
                                          <?php foreach($colleges as $college):?>
                                          <option value=<?php echo $college->college_id?>> <?php echo $college->collegename?> </option>
                                          <?php endforeach ;?>
                                    <?php endif;?>
                              </select>
                              <?php echo form_error('college_id','<div class="text-danger">','</div>'); ?>
                  </div>

                  <div class="col-md-4 text-center">
                        <label class="col-md-3 control-label text-center">  Email</label>
                              <?php echo form_input(['name' =>'email', 'class' => 'form-control', 'placeholder' => 'email','value'=>set_value('email')]);?>
                              <?php echo form_error('email','<div class="text-danger">','</div>'); ?>
                  </div>

            </div>
    

        <div class="row">
                <div class="col-md-6">
                        <div class="form-group">
                              <label class=" col-md-3 control-label"> Gender</label>
                              <select class="form-control" name="gender" >
                                    <option value=""> Select </option>
                                    <option value="Male"> Male </option>
                                    <option value="Female"> Female </option>
                              </select>
                              <?php echo form_error('gender','<div class="text-danger">','</div>'); ?>
                        </div>
                </div>
                <div class="col-md-6">
                      <label class=" col-md-3 control-label"> Role </label>
                      <select class="form-control" name="role_id">
                              <option value=""> Select </option>
                              <?php if(count($roles)): ?>
                                <?php foreach($roles as $role):?>
                                <option value=<?php echo $role->role_id?>> <?php echo $role->rolename?> </option>
                                <?php endforeach ;?>
                              <?php endif;?>
                      </select>
                      <?php echo form_error('role_id','<div class="text-danger">','</div>'); ?>
                </div>
        </div>
      
            <div class="row">
                  <div class="col-md-4">
                        <div class="form-group">
                        <label class="control-label"> Password</label>
                        <?php echo form_password(['name' =>'password', 'class' => 'form-control', 'placeholder' => 'Password']);?>
                        <?php echo form_error('username','<div class="text-danger">','</div>'); ?>
                        </div>
                  </div>
                  
                  <div class="col-md-4">
                        <label class=" control-label">Password Again</label>
                        <?php echo form_password(['name' =>'confpwd', 'class' => 'form-control', 'placeholder Again' => 'Password Again']);?>
                        <?php echo form_error('email','<div class="text-danger">','</div>'); ?>
                  </div>
            </div>
        
                 <div align="center"><br>
                        <button type="submit" class="btn btn-primary"> ADD </button>
                      <?php echo anchor("welcome", "BACK",['class'=>'btn btn-primary']);?>
                </div> 
</div> 
<?php echo form_close();?>
      
           <?php include("inc/footer.php"); ?>
       </div>
