<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>College Management System</title>
    <!-- <link rel ="stylesheet" href = "<?php echo base_url('assets/css/bootstrap.min.css');?>"/>
	  <script src = "<?php echo base_url('assets/js/bootstrap.min.js'); ?>"> </script>
	  <script src = "<?php echo base_url('assets/js/jquery-3.6.1.js'); ?>"> </script> -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

 <style type="text/css"> 
 
          .buttons{
            color:#2196f3;
            border: 1px solid #cabdbd;
            border-radius: 5px;
            padding: 2px 10px 2px 10px;
          }

 </style>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container-fluid"> 
        <div class="navbar-header col-lg-10"> 
        <a class="navbar-brand" href="">COLLEGE MANAGEMENT SYSTEM</a>
        </div>
        <div class="col-lg-2" style="margin-top:15px;" id="bs-example-navbar-collapse-2">
        <div class="btn-group">
          
          <a href="#" class="btn btn-primary"> Setting </a>
          <a href="#" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="caret"></span></a>
        <ul class="dropdown-menu" style="text-align: center;">
          <li> <?php echo anchor("admin/dashboard",'Dashboard');?></li>
          <li> <?php echo anchor("admin/coadmins",' View Co Admins');?></li>
          <li> <?php echo anchor("welcome/logout",'Logout');?></li>
         </ul>
         </div>
        </div>
       </div>
  

</nav>