<?php include("inc/header.php"); ?>
<style type="text/css">
<!--
.Estilo1 {color: #0000FF}
-->
</style>

<div class ="container">
    <?php echo form_open("admin/createStudent",['class' =>'form-horizontal']);?>
    <?php  if($msg = $this->session->flashdata('message'))
    
    if($msg != ''):?>
            <div class="row">
                <div class="col-md-6">
                    <div class="alert alert-dismissible alert-success"> 
                     <?php echo $msg;?>
                    </div>
                </div>
            </div>
        
      <?php endif;?>
   
        <h3 class="text-center Estilo1" style="text-decoration: underline">ADD STUDENT</h3>
        <!-- <hr>  -->
         <div class="row" align="center">
              <div class="col-md-4">
                    <div class="form-group" >
                          <label class="control-label"> Student Name</label>
                          <?php echo form_input(['name' =>'studentname', 'class' => 'form-control', 'placeholder' => 'Student Name','value'=>set_value('studentname')]);?>
                          <?php echo form_error('studentname','<div class="text-danger">','</div>'); ?>
                    </div>
           </div>
                
                <div class="col-md-4" align="center">
                        <label class="control-label"> College Name </label>
                        <select class="form-control" name="college_id">
                                <option value=""> Select </option>
                                <?php if(count($colleges)): ?>
                                      <?php foreach($colleges as $college):?>
                                      <option value=<?php echo $college->college_id?>> <?php echo $college->collegename?> </option>
                                      <?php endforeach ;?>
                                <?php endif;?>
                        </select>
                        <?php echo form_error('college_id','<div class="text-danger">','</div>'); ?>
                </div>
        </div>
          <div class="col-md-4" align="center">
              <label class="col-md-3 control-label" align="center"> Email</label>
              <?php echo form_input(['name' =>'email', 'class' => 'form-control', 'placeholder' => 'email','value'=>set_value('email')]);?>
              <?php echo form_error('email','<div class="text-danger">','</div>'); ?>
          </div>
</div>

        <div class="row">
                <div class="col-md-4" align="center">
                      <div class="form-group">
                            <label class="control-label"> Gender</label>
                            <select class="form-control" name="gender" >
                              <option value=""> Select </option>
                              <option value="Male"> Male </option>
                              <option value="Female"> Female </option>
                            </select>
                            <?php echo form_error('gender','<div class="text-danger">','</div>'); ?>
                      </div>
                </div>
              
               
              <div class="col-md-4" align="center">
                    <div class="form-group">
                          <label class="control-label">Course</label>
                          <?php echo form_input(['name' =>'course', 'class' => 'form-control', 'placeholder' => 'Course','value'=>set_value('course')]);?>
                          <?php echo form_error('course','<div class="text-danger">','</div>'); ?>
                    </div>
                </div>
       
        
                <div align="center"><br>
                        <button type="submit" class="btn btn-primary"> ADD </button>
                      <?php echo anchor("welcome", "BACK",['class'=>'btn btn-primary']);?>
                </div>

       <div align="center"><?php echo form_close();?>
           </div>
           <?php include("inc/footer.php"); ?>
       </div>
