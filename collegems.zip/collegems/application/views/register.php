<?php include("inc/header.php"); ?>
<style type="text/css">
<!--
.Estilo1 {color: #0000FF}
-->
</style>

<div class ="container">
    
<?php echo form_open("welcome/adminSignup",['class' =>'form-horizontal']);?>
    <?php  if($msg = $this->session->flashdata('message')):?>
    
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-dismissible alert-success"> 
                <?php echo $msg;?>
                </div>
            </div>
        </div>
        
        <?php endif;?>
       
        <h3 class="text-center Estilo1" style="text-decoration: underline">ADMIN REGISTRATION</h3>
        <!-- <hr>  -->
         <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                    <label class="control-label"> Username</label>
                      <?php echo form_input(['name' =>'username', 'class' => 'form-control', 'placeholder' => 'Username','value'=>set_value('username')]);?>
                      <?php echo form_error('username','<div class="text-danger">','</div>'); ?>
                  </div>
                </div>
                  <div class="col-md-4">
                    <label class="col-md-3 control-label"> Email</label>
                    <?php echo form_input(['name' =>'email', 'class' => 'form-control', 'placeholder' => 'email','value'=>set_value('email')]);?>
                    <?php echo form_error('email','<div class="text-danger">','</div>'); ?>
                  </div>
        </div>

        <div class="row">
           <div class="col-md-4">
             <div class="form-group">
               <label class="control-label"> Gender</label>
               <select class="form-control" name="gender" >
                <option value=""> Select </option>
                <option value="Male"> MAle </option>
                <option value="Female"> Female </option>
              </select>
              <?php echo form_error('gender','<div class="text-danger">','</div>'); ?>
            </div>
          </div>
          <div class="col-md-4">
            <label class="control-label"> Role </label>
              <select class="form-control" name="role_id">
                 <option value=""> Select </option>
                   <?php if(count($roles)): ?>
                   <?php foreach($roles as $role):?>
                   <option value=<?php echo $role->role_id?>> <?php echo $role->rolename?> </option>
                  <?php endforeach ;?>
                <?php endif;?>
            </select>
            <?php echo form_error('role_id','<div class="text-danger">','</div>'); ?>
          </div>
        </div>
      
         <div class="row">
          <div class="col-md-4">
                 <div class="form-group">
                  <label class="control-label"> Password</label>
                  <?php echo form_password(['name' =>'password', 'class' => 'form-control', 'placeholder' => 'Password']);?>
                  <?php echo form_error('username','<div class="text-danger">','</div>'); ?>
            </div>
           </div>
            <div class="col-md-4">
                  <label class=" control-label">Password Again</label>
                  <?php echo form_password(['name' =>'confpwd', 'class' => 'form-control', 'placeholder Again' => 'Password Again']);?>
                  <?php echo form_error('email','<div class="text-danger">','</div>'); ?>
           </div>
        </div>
        
        <div align="center"><br>
            <button type="submit" class="btn btn-primary"> REGISTER </button>
            <?php echo anchor("welcome", "BACK",['class'=>'btn btn-primary']);?>
        </div>
</div> 
            <div align="right"><?php echo form_close();?>
           </div>
           <?php include("inc/footer.php"); ?>
</div>
